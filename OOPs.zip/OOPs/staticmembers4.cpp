#include <iostream>
using namespace std;
class B;
class A
{ static B b;

	int x;
public:
	A() { cout << "A's constructor called " << endl; }
	static B getb(){return b;}
};

class B
{
	static A a;
	int y;
public:
	B() { cout << "B's constructor called " << endl; }
	static A getA() { return a; }
};

A B::a;
B A::b; // definition of a

int main()
{
	// static member 'a' is accessed without any object of B
	A a = B::getA();

	return 0;
}
