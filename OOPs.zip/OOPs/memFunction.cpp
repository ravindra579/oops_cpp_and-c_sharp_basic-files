// C++ program to demonstrate function 
// declaration outside class 

#include <bits/stdc++.h> 
using namespace std; 
class TSC 
{ 
	public: 
	string TSCname; 
	int id; 
	
	// printname is not defined inside class definition 
	void printname(); 
	
	// printid is defined inside class definition 
	void printid() 
	{ 
		cout << "TSC id is: " << id; 
	} 
}; 

// Definition of printname using scope resolution operator :: 
void TSC::printname() 
{ 
	cout << "TSCname is: " << TSCname; 
} 
int main() { 
	
	TSC obj1; 
	obj1.TSCname = "xyz"; 
	obj1.id=15; 
	
	// call printname() 
	obj1.printname(); 
	cout << endl; 
	
	// call printid() 
	obj1.printid(); 
	return 0; 
} 
