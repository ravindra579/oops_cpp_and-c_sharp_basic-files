// C++ program to demonstrate working of 
// inline namespaces 
#include <iostream> 
using namespace std; 

namespace ns1 
{ 
inline namespace ns2 
{ 
	int var = 10; 
} 
} 

int main() 
{ 
cout << ns1::var; 
return 0; 
}
