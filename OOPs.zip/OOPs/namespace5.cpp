// A C++ code to demonstrate that we can define 
// methods outside namespace. 
#include <iostream> 
using namespace std; 

// Creating a namespace 
namespace ns 
{ 
	void display(); 
	class TSC 
	{ 
	public: 
	void display(); 
	}; 
} 

// Defining methods of namespace 
void ns::TSC::display() 
{ 
	cout << "ns::TSC::display()\n"; 
} 
void ns::display() 
{ 
	cout << "ns::display()\n"; 
} 

// Driver code 
int main() 
{ 
	ns::TSC obj; 
	ns::display(); 
	obj.display(); 
	return 0; 
} 
