// A C++ program to demonstrate use of class 
// in a namespace 
#include <iostream> 
using namespace std; 

namespace ns 
{ 
	// Only declaring class here 
	class TSC; 
} 

// Defining class outside 
class ns::TSC
{ 
public: 
	void display() 
	{ 
		cout << "ns::TSC::display()\n"; 
	} 
}; 

int main() 
{ 
	//Creating Object of TSC Class 
	ns::TSC obj; 
	obj.display(); 
	return 0; 
} 
