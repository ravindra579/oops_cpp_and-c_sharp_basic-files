#include<iostream> 
class Test { 
static void fun() {} 
void fun() {} // compiler error 
}; 

int main() 
{ 
getchar(); 
return 0; 
} 