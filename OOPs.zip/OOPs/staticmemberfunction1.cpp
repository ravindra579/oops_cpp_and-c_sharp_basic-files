#include<iostream>
class Test {
static Test * fun() {
	return this; // compiler error
}
};

int main()
{
    Test t =new Test();
t Test ::fun();

return 0;
}
