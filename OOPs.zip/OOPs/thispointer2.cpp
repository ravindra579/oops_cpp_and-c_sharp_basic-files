/* Reference to the calling object can be returned */
Test& Test::func () 
{ 
// Some processing 
return *this; 
} 
