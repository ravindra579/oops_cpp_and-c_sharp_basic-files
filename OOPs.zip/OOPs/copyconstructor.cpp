// Illustration
#include "iostream"
#include "string"
using namespace std;

class student{
private:
    int admno;
    char sname[20];
    float eng;
    float math;
    float science;
    float ctotal(float eng,float math,float science){
    return math+science+eng;
    }
public:
    void Takedata(int a,char s[20],float e,float sc,float m){
    admno=a;
    eng=e;
    science=sc;
    math=m;
    //ctoatl(eng,math,science);
    void displaydata(){
    cout<<admno<<endl<<sname<<endl<<eng<<endl<<science<<endl<<math<<endl<<total<<endl;
    }
};
void main()
{
    student obj;
    obj.Takedata(1099,ravi,80,90,99);
    obj.displaydata();
    return 0;
    }
