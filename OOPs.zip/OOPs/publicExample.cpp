// C++ program to demonstrate public
// access modifier

#include<iostream>
using namespace std;

// class definition
class Circle
{
	public:
		double radius;

		double compute_area()
		{
			return 3.14*radius*radius;
		}
        double compute_circum()
        {

            return 2*3.14*radius;
        }
};

// main function
int main()
{
	Circle obj;

	// accessing public datamember outside class
	obj.radius = 5.5;

	cout << "Radius is: " << obj.radius << "\n";
	cout << "Area is: " << obj.compute_area();
	cout << "circuference is: " << obj.compute_circum();
	return 0;
}
